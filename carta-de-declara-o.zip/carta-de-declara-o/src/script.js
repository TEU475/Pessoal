const particlesContainer = document.getElementById("particles");

const emojis = [
  "❤️", "💖", "💘", "💞", "💕", "💓", "💗",
  "🥰", "😍", "😘",
  "💑", "👩‍❤️‍👨",
  "💍", "🌹", "💌", "🤍"
];

function createParticle() {
  const particle = document.createElement("div");
  particle.classList.add("particle");
  particle.textContent = emojis[Math.floor(Math.random() * emojis.length)];
  const size = Math.random() * 18 + 22;
  particle.style.fontSize = size + "px";
  particle.style.left = Math.random() * 100 + "vw";
  const duration = Math.random() * 6 + 10;
  particle.style.animationDuration = duration + "s";
  particlesContainer.appendChild(particle);
  setTimeout(() => particle.remove(), duration * 1000);
}

setInterval(createParticle, 280);

/* Coração interativo */
const heart = document.getElementById("heart");
const secret = document.getElementById("secret");

const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
function playChime() {
  const oscillator = audioCtx.createOscillator();
  const gainNode = audioCtx.createGain();
  oscillator.type = "sine";
  oscillator.frequency.setValueAtTime(880, audioCtx.currentTime);
  gainNode.gain.setValueAtTime(0.001, audioCtx.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.15, audioCtx.currentTime + 0.05);
  gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.8);
  oscillator.connect(gainNode);
  gainNode.connect(audioCtx.destination);
  oscillator.start();
  oscillator.stop(audioCtx.currentTime + 0.8);
}

if (heart && secret) {
  heart.addEventListener("click", () => {
    heart.classList.add("clicked");
    secret.classList.add("show");
    if (audioCtx.state === "suspended") audioCtx.resume();
    playChime();
  });
}

/* Transição de fundo por cartão */
const page = document.querySelector(".page");

const colors = [
 "rgb(255,180,185)", // rosa bem suave inicial
  "rgb(250,155,165)", // rosa delicado
  "rgb(242,130,150)", // rosa doce e elegante
  "rgb(232,105,135)", // rosa equilibrado
  "rgb(220,85,120)",  // rosa vibrante suave
  "rgb(205,65,105)",  // rosa apaixonado
  "rgb(192,52,96)",   // rosa profundo
  "rgb(186,48,92)",   // rosa intenso
  "rgb(179,48,89)"    // rosa romântico intenso final
];

function updateBackground(index) {
  document.body.style.transition = "background-color 0.8s ease";
  document.body.style.backgroundColor = colors[index];
}

let currentIndex = 0;
updateBackground(currentIndex);

page.addEventListener("scroll", () => {
  const scrollTop = page.scrollTop;
  const height = window.innerHeight;
  let index = Math.round(scrollTop / height);
  index = Math.min(index, colors.length - 1);
  if (index !== currentIndex) {
    currentIndex = index;
    updateBackground(currentIndex);
  }
});
