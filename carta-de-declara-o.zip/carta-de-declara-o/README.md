# Carta de Declaração

A Pen created on CodePen.

Original URL: [https://codepen.io/qhmimyhj-the-bold/pen/EayvByB](https://codepen.io/qhmimyhj-the-bold/pen/EayvByB).

